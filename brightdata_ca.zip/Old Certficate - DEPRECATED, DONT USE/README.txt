This SSL certificate will expire in 2026 and is being phased out. 

**Please do not use this certificate for new projects**

We recommend that you migrate to the new certificate (available inside the zip file) before the previous one expires. 

Keep in mind that the new certificate requires you to use port 33335, meaning your proxy host will be from now on: brd.superproxy.io:33335